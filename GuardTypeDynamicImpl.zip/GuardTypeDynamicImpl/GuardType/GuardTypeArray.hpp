//
//  GuardTypeArray.hpp
//  GuardType
//
//  Created by BenjaminZhou on 16/4/9.
//  Copyright © 2016年 BenjaminZhou. All rights reserved.
//

#ifndef GuardTypeArray_hpp
#define GuardTypeArray_hpp

#include <iostream>
#include <iomanip>
#include "GuardType.hpp"
#include "Ptr.hpp"
#include "ArrayIndexProvider.hpp"

//-----------------------------------------------------------------------------
//                            class GuardTypeArray

template<typename T>
class GuardTypeArray<T, 1> {
public:
    typedef Ptr<T, 1, 1>    iterator;
    
    typedef GuardType<T>    value_type;
    
    friend class ArrayIndexProvider<T, 1>;
    
    friend class Ptr<T, 1, 1>;
    
private:
    GuardTypeArray();
private:
    size_t dementions[2];
protected:
    T*   array;
    bool isAlloc;
public:
    std::string id;
    
public:
    ~GuardTypeArray() {
        if(isAlloc) {
            delete[] array;
        }
    }
    
    GuardTypeArray(const GuardTypeArray<T, 1>& gt)
    : id(GT::GetNewIdByIncreaseId(gt.id)), isAlloc(true)
    {
        size_t elementCount = this->dementions[1] = gt.dementions[1];
        this->dementions[0] = 1;
        array = new T[elementCount];
        T* begin = array;
        T* end = begin + elementCount;
        for(T* iter=begin; iter!=end; iter++) {
            new(iter) T();
        }
    }
    
    GuardTypeArray(size_t n, const char* id = GuardConfig::defaultId.c_str())
    : id(GT::GetNewId(id)), array(new T[n]), isAlloc(true)
    {
        assert( n>0);
        dementions[0] = 1;
        dementions[1] = n;
        T* begin = array;
        T* end = begin + n;
        for(T* iter=begin; iter!=end; iter++) {
            new(iter) T();
        }
    }
    
    //template<typename T>
    //template<int N, typename U>
    //GuardTypeArray<T, 1>::GuardTypeArray(const U (&pArr)[N], const std::string& id)
    //: id(GT::GetNewId(id)), array(new T[N]), isAlloc(true)
    //{
    //    for(int i=0; i<N; i++) {
    //        array[i] = pArr[i];
    //    }
    //}
    
    template<int N, typename U>
    GuardTypeArray(const U (&pArr)[N], const char* id = GuardConfig::defaultId.c_str())
    : id(id), isAlloc(false)
    {
        this->dementions[0] = 1;
        this->dementions[1] = N;
        array = const_cast<int*>(&pArr[0]);
        isAlloc = false;
    }
    
    template<int N, typename U>
    GuardTypeArray(bool isReferenceFromArray, const U (&pArr)[N])
    : id(GT::GetNewId()) {
        this->dementions[0] = 1;
        this->dementions[1] = N;
        if(isReferenceFromArray == false) {
            array = new T[N];
            isAlloc = true;
            for(int i=0; i<N; i++) {
                array[i] = pArr[i];
            }
        } else {
            array = const_cast<int*>(&pArr[0]);
            isAlloc = false;
        }
    }
    
    size_t size() const {
        return this->dementions[1];
    }
    
    size_t length() const {
        return this->dementions[1];
    }
    
    Ptr<T, 1, 1> begin() const  {
        return Ptr<T, 1, 1>(ArrayIndexProvider<T, 1>(*this, 0), 0);
    }
    
    Ptr<T, 1, 1> end() const  {
        return Ptr<T, 1, 1>(ArrayIndexProvider<T, 1>(*this, dementions[1]), 0);
    }
    
    GuardType<T> operator [] (size_t n) {
        DataProvider<T>* data = new ArrayIndexProvider<T, 1>(*this, n);
        return GuardType<T>(data);
    }
    
    const GuardType<T> operator [] (size_t n) const {
        DataProvider<T>* data = new ArrayIndexProvider<T, 1>(*this, n);
        return GuardType<T>(data);
    }
    
    operator const Ptr<T, 1, 1> () {
        return Ptr<T, 1, 1>(ArrayIndexProvider<T, 1>(*this, 0), 0);
    }
    
    bool operator == (const GuardTypeArray<T, 1>& gt) const {
        return this->array == gt.array;
    }
    
    bool operator != (const GuardTypeArray<T, 1>& gt) const {
        return this->array != gt.array;
    }
    
    bool operator == (const Ptr<T, 1, 1>& ptr) const {
        return this->array == ptr.pos;
    }
    
    bool operator < (const Ptr<T, 1, 1>& ptr) const {
        return this->array < ptr.pos;
    }
    
    bool operator <= (const Ptr<T, 1, 1>& ptr) const {
        return this->array <= ptr.pos;
    }
    
    bool operator > (const Ptr<T, 1, 1>& ptr) const {
        return this->array > ptr.pos;
    }
    
    bool operator >= (const Ptr<T, 1, 1>& ptr) const {
        return this->array >= ptr.pos;
    }
    
    bool operator != (const Ptr<T, 1, 1>& ptr) const {
        return this->array != ptr.pos;
    }
    
    template<typename U>
    Ptr<T, 1, 1> operator + (U n) {
        return Ptr<T, 1, 1>(*this, n);
    }

    friend std::istream& operator >> (std::istream &   si,
                                      GuardTypeArray& gt) {
        T data;
        if(GuardConfig::_ARRAY_IO_TIP_SWITCH == true) {
            if(typeid(si) == typeid(std::cin)) {
                std::cout<< "Please input ";
                std::cout<< "["<< gt.size() << "] Datas "
                << gt.id << ": " << std::endl;
            }
        }
        T * arr = gt.array;
        for (int i=0; i<gt.size(); i++) {
            si >> data;
            arr[i] = data;
        }
        return si;
    }
    
    friend std::ostream& operator << (std::ostream &        so,
                                      const GuardTypeArray& gt) {
        T* p = gt.array;
        for (int i=0; i<gt.size(); i++) {
            so << std::setw(GuardConfig::_ARRAY_OUT_PUT_INTERVAL)
            << " " << *(p+i) << " ";
        }
        so << std::endl << std::endl;
        return so;
    }
};

#endif /* GuardTypeArray_hpp */
