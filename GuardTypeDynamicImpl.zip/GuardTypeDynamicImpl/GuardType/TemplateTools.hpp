//
//  TemplateTools.hpp
//  GuardType
//
//  Created by BenjaminZhou on 16/4/13.
//  Copyright © 2016年 BenjaminZhou. All rights reserved.
//

#ifndef TemplateTools_hpp
#define TemplateTools_hpp

#include <iostream>

template<typename T>
class GuardType;

template<typename T, int Demention>
class GuardTypeArray;

//--------------------------------------------------------------------------
//                             GT template tools

template<typename T>
void AddId(const T& id) {
    GuardConfig::idArray.push(id);
}

template<typename T, typename ...U>
void AddId(const T& id, const U&...ids) {
    GuardConfig::idArray.push(id);
    AddId(ids...);
}

namespace GT {
    
    //---------------------------------------------------------------------------
    //                              GT::type_traits
    
    template<typename T>
    struct type_traits {
        typedef T value_type;
    };
    
    template<typename T>
    struct type_traits<GuardType<T> > {
        typedef T value_type;
    };
    
    template<typename T, typename U>
    struct type_equals {
        enum { value = 0 };
    };
    
    template<typename T>
    struct type_equals<T, T> {
        enum { value = 1 };
    };
    
    template<typename... T>
    int printf(const char * s, const T&... arg1) {
        return std::printf(s, static_cast<typename type_traits<T>::value_type>(arg1)...);
    }
    
    
    
    
    //---------------------------------------------------------------------------
    //                              GT::LargerType
    
    
    template<typename T>
    struct TypePriority {
        enum { N = 9999 };
    };
    
    template<typename T, typename U>
    struct PriorityIsLarger {
        enum { result = TypePriority<T>::N > TypePriority<U>::N};
    };
    
    template <int IsLarger, typename T, typename U>
    struct GetLargerType {
    };
    
    template <typename T, typename U>
    struct GetLargerType<1, T, U> {
        typedef T value_type;
    };
    
    template <typename T, typename U>
    struct GetLargerType<0, T, U> {
        typedef U value_type;
    };
    
    template <typename T, typename U>
    struct LargerType {
        typedef typename GetLargerType<PriorityIsLarger<T, U>::result , T, U>::value_type value_type;
    };
    
    
    
    
    template<>
    struct TypePriority<bool> {
        enum { N = 0 };
    };
    
    template<>
    struct TypePriority<unsigned char> {
        enum { N = 1 };
    };
    
    template<>
    struct TypePriority<char> {
        enum { N = 2 };
    };
    
    template<>
    struct TypePriority<unsigned short> {
        enum { N = 3 };
    };
    
    template<>
    struct TypePriority<short> {
        enum { N = 4 };
    };
    
    template<>
    struct TypePriority<unsigned int> {
        enum { N = 5 };
    };
    
    template<>
    struct TypePriority<int> {
        enum { N = 6 };
    };
    
    template<>
    struct TypePriority<unsigned long> {
        enum { N = 7 };
    };
    
    template<>
    struct TypePriority<long> {
        enum { N = 8 };
    };
    
    template<>
    struct TypePriority<float> {
        enum { N = 9 };
    };
    
    template<>
    struct TypePriority<double> {
        enum { N = 10 };
    };
    
    template<>
    struct TypePriority<long double> {
        enum { N = 11 };
    };
    
    
    
    
    //---------------------------------------------------------------------------
    //                              PackExpres
    // (data1) op (data2)
    
    template<typename T>
    std::string CalcString(const GuardType<T>& data) {
        return data.CalcString();
    }
    
    template<typename T>
    std::string CalcString(T data) {
        return NumericToString(data);
    }
    
    template<typename U, typename V>
    const std::string PackWithBracket(const U& data1,
                                      const std::string& opStr,
                                      const V& data2) {
        std::string calcExpress;
        std::string data1CalcString = CalcString(data1);
        std::string data2CalcString = CalcString(data2);
        if(MinCalcPriorityOf(data1CalcString)
           <= PriorityOfSymbol(opStr))
            calcExpress = "("+data1CalcString+")" + opStr;
        else
            calcExpress = data1CalcString + opStr;
        
        if(PriorityOfSymbol(opStr) >= MinCalcPriorityOf(data2CalcString))
            calcExpress += "("+data2CalcString+")";
        else
            calcExpress += data2CalcString;
        return calcExpress;
    }
    
    template<typename T>
    const std::string NumericToString(const T& data) {
        std::string num = std::to_string(data);
        if((GT::type_equals<T, float>::value
            || GT::type_equals<T, double>::value
            || GT::type_equals<T, long double>::value)) {
            while (num.back() == '0') {
                num.pop_back();
            }
            if(num.back() == '.') {
                num.push_back('0');
            }
        }
        return num;
    }

    
    
    //---------------------------------------------------------------------------
    //                              InitWithCArray
    
    template<int D>
    struct InitWithCArray {
        template<typename T, int Demention, typename U, int N>
        static void Init(const GuardTypeArray<T, Demention>& gt, const U (&arr)[N]) {
            const_cast<size_t&>(gt.dementions[D]) = N;
            InitWithCArray<D-1>::Init(gt, arr[0]);
        }
    };
    template<>
    struct InitWithCArray<1> {
        template<typename T, int Demention, typename U, int N>
        static void Init(const GuardTypeArray<T, Demention>& gt, const U (&arr)[N]) {
            const_cast<size_t&>(gt.dementions[1]) = N;
            const_cast<GuardTypeArray<T, Demention>&>(gt).array = const_cast<int*>(&arr[0]);
            const_cast<GuardTypeArray<T, Demention>&>(gt).InitDementions();
        }
    };

}

#endif /* TemplateTools_hpp */
