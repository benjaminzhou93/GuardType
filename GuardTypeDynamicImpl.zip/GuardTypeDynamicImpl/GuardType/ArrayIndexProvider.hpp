//
//  ArrayIndexProvider.hpp
//  GuardType
//
//  Created by BenjaminZhou on 16/4/13.
//  Copyright © 2016年 BenjaminZhou. All rights reserved.
//

#ifndef ArrayIndexProvider_hpp
#define ArrayIndexProvider_hpp

#include "DataProvider.hpp"
#include <iomanip>

template<typename T, int Demention>
class GuardTypeArray;

template<typename T, int Demention, int N>
class Ptr;

//--------------------------------------------------------------------------
//                            class ArrayIndexProvider

template<typename T, int Demention>
class ArrayIndexProvider : public DataProvider<T> {
    friend class Ptr<T, Demention, Demention>;
private:
    T* pos;
    GuardTypeArray<T, Demention> * array;
public:
    
    ArrayIndexProvider(const GuardTypeArray<T, Demention>& arr, size_t n) {
        this->array = &const_cast<GuardTypeArray<T, Demention>& >(arr);
        pos = arr.array;
        OUT_OF_INDEX_DETECT__(this->OutOfIndexDetect(Demention-1, n));
        pos += n * arr.dementions[Demention-1];
    }
    
    ArrayIndexProvider(const ArrayIndexProvider<T, Demention>& frontIndex, int N, size_t n) {
        this->array = frontIndex.array;
        pos = frontIndex.pos;
        OUT_OF_INDEX_DETECT__(this->OutOfIndexDetect(N, n));
        pos += n * array->dementions[N];
    }
    
    T& Data()  {
        return *pos;
    }
    
    const std::string Id() const {
        std::string id = array->id;
        char str_idx[32];
        size_t shift = pos - array->array;
        for (int i = Demention-1; i >= 0; i--) {
            sprintf(str_idx, "[%ld]", shift/array->dementions[i]);
            shift %= array->dementions[i];
            id += str_idx;
        }
        return id;
    }
    
    void DataChangedCallBack() const {
        T* p = array->array;
        T* end = p + array->dementions[Demention];
        size_t lineCount = array->dementions[1];
        
        while(p < end) {
            for(int j = 0; j < lineCount; ++j, ++p) {
                if(p == this->pos) {
                    GuardConfig::so << std::setw(GuardConfig::_ARRAY_OUT_PUT_INTERVAL)
                    << "[" << *(p) << "]";
                } else {
                    GuardConfig::so << std::setw(GuardConfig::_ARRAY_OUT_PUT_INTERVAL)
                    << " " << *(p) << " ";
                }
            }
            GuardConfig::so << std::endl;
            for(int j = 2; j < Demention; j++) {
                if((p-array->array) % array->dementions[j] == 0) {
                    GuardConfig::so << std::endl;
                }
            }
        }
    }
    
    void OutOfIndexDetect(int N, size_t n) {
        if(n < array->dementions[N+1]/array->dementions[N]) return;
        std::string usedIndex = array->id;
        size_t shift = pos - array->array;
        size_t index = 0;
        char str_idx[32];
        for (int i = Demention-1; i >= 0; i--) {
            index = (i == N ? n : shift/array->dementions[i]);
            shift %= array->dementions[i];
            sprintf(str_idx, "[%ld]", index);
            usedIndex += str_idx;
        }
        std::string maxIndex = array->id;
        for (int i = Demention; i > 0; i--) {
            sprintf(str_idx, "[%ld]", array->dementions[i]/array->dementions[i-1]);
            maxIndex += str_idx;
        }
        std::cout << "Array: " << maxIndex << ", Used: " << usedIndex << std::endl;
        int OutOfIndex = 0;
        assert(OutOfIndex);
    }
};

#endif /* ArrayIndexProvider_hpp */
