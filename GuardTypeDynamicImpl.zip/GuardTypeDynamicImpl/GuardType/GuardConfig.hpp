//
//  GuardConfig.hpp
//  GuardType
//
//  Created by BenjaminZhou on 16/4/9.
//  Copyright © 2016年 BenjaminZhou. All rights reserved.
//

#ifndef GuardConfig_hpp
#define GuardConfig_hpp


#include <map>
#include <queue>
#include <string>
#include <iostream>

//---------------------------------------------------------------------------
//                              GuardConfig



// 指定程序是否需要进行下标溢出检测
#define OUT_OF_INDEX_DETECT__(detect)           //detect

// 指定程序是否需要输出到控制台
#define OUTPUT_TRACE_SWITCH__(trace)            //trace

// 数据被修改时执行用户指定方法
#define VALUE_CHANGED_DO_DECLARE(member)        //member,
#define VALUE_CHANGED_DO_____(someting)         //someting

// 数据被读取时执行用户指定方法
#define VALUE_BE_READED_DO_DECLARE(member)      //member,
#define VALUE_BE_READED_DO___(someting)         //someting

// 数据被修改时通过函数参数返回原有值，和改变后的值
#define OLD_TO_NEW_VALUE_DO_DECLARE(member)     //member,
#define OLD_TO_NEW_VALUE_DO__(someting)         //someting

// 是否定义用于跟踪控制台输出的字符串
#define TRACE_STRING_SAVE_DECLARE(member)       //member,
#define TRACE_STRING_SAVE____(string)           //string

// 数据读写的提示位置
#define _SPACES "\t\t\t\t"



// 作为基类只有一个实例对象作为配置
class GuardConfig
{
    GuardConfig();
    GuardConfig(GuardConfig&);
    template<typename T>
    friend class GuardType;
public:
    
    // 开启所有跟踪
    static void TurnAllGuardOff();
    // 关闭所有跟踪
    static void TurnAllGuardOn();
    
    // 读取单元素跟踪开关   GT: 99 （读取 GT 内容为 99）
    static void TurnReadSwitch(bool yes);
    // 算数运算跟踪开关     +, -, *, /, %, ^, &,|, ~, <<, >>
    static void TurnMathSwitch(bool yes);
    // 逻辑运算跟踪开关     !, &&, ||
    static void TurnLogicSwitch(bool yes);
    // 比较运算跟踪开关     <, >, <=, >=, !=, ==
    static void TurnCompareSwitch(bool yes);
    // 赋值运算跟踪开关     =, ++, --, +=, -=, *=, /=, %=, ^=, <<=, >>=
    static void TurnAssignSwitch(bool yes);
    static void TurnOutPutCalcTraceSwitch(bool yes);
    static void TurnOutPutCalcExpressSwitch(bool yes);
    
    static void TurnIOTipSwitch(bool yes);         // 从键盘读取数据时提示开关
    static void TurnArrayOutPutSwitch(bool yes);   // 输出整行数组跟踪开关
    static void TurnCalcExpressIdOrNum(bool yes);  // 输出计算表达式yes为Id,no为num
    static void SetArrayOutPutInterval(int n);     // 调整数组元素之间的输出间隔
    
    static bool _TRACE_READ_SWITCH;                // 读取单元素跟踪开关
    static bool _OUTPUT_TRACE_SWITCH;              // 输出计算过程跟踪开关
    static bool _OUT_PUT_EXPRES_SWITCH;            // 输出计算表达式跟踪开关
    static bool _OUT_PUT_EXPRES_ID_OR_NUM_SWITCH;  // 设置Expres表达方式为输出纯id还是纯num
    static bool _ARRAY_IO_TIP_SWITCH;              // 从键盘读取数据时提示开关
    static bool _ARRAY_OUT_PUT_SWITCH;             // 输出数组跟踪开关
    static int  _ARRAY_OUT_PUT_INTERVAL;           // 输出的数组元素之间的间隔
    const static bool defaultGuard;                // 默认跟踪全部开启
public:
    static std::string defaultId;
    static std::ostream& so;                       // 默认跟踪输出到 std::cout
    static std::queue<std::string> idArray;
    static std::map<std::string, bool> rule;
    static GuardConfig config;
};


enum OnOrOff {OFF = 0, ON = 1};

void TurnTrace(OnOrOff s);

void TurnExpres(OnOrOff s);

#define GTRule GuardConfig::rule

#endif /* GuardConfig_hpp */
