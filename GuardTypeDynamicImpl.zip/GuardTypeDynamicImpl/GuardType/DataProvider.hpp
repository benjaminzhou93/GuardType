//
//  DataProvider.hpp
//  GuardType
//
//  Created by BenjaminZhou on 16/4/10.
//  Copyright © 2016年 BenjaminZhou. All rights reserved.
//

#ifndef DataProvider_hpp
#define DataProvider_hpp

#include <iostream>
#include "Tools.hpp"

//--------------------------------------------------------------------------
//                            class DataProvider

template<typename T>
class DataProvider {
public:
    virtual T& Data() = 0;
    
    virtual const std::string Id() const = 0;
    
    virtual void DataChangedCallBack() const {}
    
    virtual ~DataProvider(){}
    
};

#endif /* DataProvider_hpp */
