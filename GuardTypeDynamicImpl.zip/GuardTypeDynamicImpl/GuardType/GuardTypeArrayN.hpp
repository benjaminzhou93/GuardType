//
//  GuardTypeArrayN.hpp
//  GuardType
//
//  Created by BenjaminZhou on 16/4/9.
//  Copyright © 2016年 BenjaminZhou. All rights reserved.
//

#ifndef GuardTypeArrayN_hpp
#define GuardTypeArrayN_hpp

#include <iostream>
#include <iomanip>
#include "GuardType.hpp"
#include "PtrN.hpp"
#include "GuardTypeArray.hpp"

//---------------------------------------------------------------------------
//                            class GuardTypeArray

template<typename T, int Demention>
class GuardTypeArray {
public:
    friend class ArrayIndexProvider<T, Demention>;
    
    friend class Ptr<T, Demention, Demention>;
    
    template<int D>
    friend struct GT::InitWithCArray;
    
private:
    GuardTypeArray();
private:
    size_t dementions[Demention+1];
protected:
    T*   array;
    bool isAlloc;
public:
    std::string id;
    
public:
    ~GuardTypeArray() {
        if(isAlloc) {
            delete[] array;
        }
    }
    
    GuardTypeArray(const GuardTypeArray<T, Demention>& gt)
    : id(GT::GetNewIdByIncreaseId(gt.id)), isAlloc(true)
    {
        for (int i=0; i<Demention; i++) {
            this->dementions[i] = gt.dementions[i];
        }
        size_t elementCount = this->dementions[1];
        array = new T[elementCount];
        T* pSource = gt.array;
        for (int i=0; i<elementCount; i++) {
            *(array + i) = *(pSource + i);
        }
    }
    
    //template<int N, typename U>
    //GuardTypeArray(const U (&pArr)[N], const std::string& id)
    //: id(GT::GetNewId(id)), array(new T[N]), isAlloc(true)
    //{
    //    this->dementions[0] = 1;
    //    GT::InitWithCArray<Demention>::Init(*this, pArr);
    //}
    
    template<int N, typename U>
    GuardTypeArray(const U (&pArr)[N], const char* id = GuardConfig::defaultId.c_str())
    : id(GT::GetNewId(id)), isAlloc(false)
    {
        GT::InitWithCArray<Demention>::Init(*this, pArr);
    }
    
    template<int N, typename U>
    GuardTypeArray(bool isReferenceFromArray, const U (&pArr)[N])
    : id(GT::GetNewId()), isAlloc(isReferenceFromArray) {
        GT::InitWithCArray<Demention>::Init(*this, pArr);
    }
    
    template<typename ...Int>
    GuardTypeArray(size_t first, Int...n)
    : id(GT::GetNewId()), isAlloc(true)
    {
        this->InitWithIndexs<Demention>(first, n...);
    }
    
    template<int N, typename ...V>
    void InitWithIndexs(size_t index, V ...n) {
        this->dementions[N] = index;
        this->InitWithIndexs<N-1>(n...);
    }
    
    template<int N, typename ...V>
    void InitWithIndexs(const std::string& id) {
        static_assert(N == 0, "Array init with wrong index count");
        this->id = id;
        this->AllocWithDementions();
    }
    
    template<int N, typename ...V>
    void InitWithIndexs(size_t index) {
        static_assert(N == 1, "Array init with wrong index count");
        this->dementions[Demention] = index;
        this->id = GT::GetNewId();
        this->AllocWithDementions();
    }
    
    void AllocWithDementions() {
        this->dementions[0] = 1;
        for(int i = 0; i < Demention; i++) {
            this->dementions[i+1] *= this->dementions[i];
        }
        
        if(this->isAlloc == false) return;
        size_t allElement = this->dementions[Demention];
        this->array = new T[allElement];
        T* begin = array;
        T* end = begin + allElement;
        for(T* iter=begin; iter!=end; iter++) {
            new(iter) T();
        }
    }
    
    void InitDementions() {
        this->dementions[0] = 1;
        for(int i = 0; i < Demention; i++) {
            this->dementions[i+1] *= this->dementions[i];
        }
        
        if(this->isAlloc == false) return;
        size_t allElement = this->dementions[Demention];
        T* source = array;
        this->array = new T[allElement];
        T* begin = array;
        T* end = begin + allElement;
        for(T* iter=begin; iter!=end; iter++) {
            new(iter) T(*source++);
        }
    }
    
    size_t size() const {
        return this->dementions[Demention];
    }
    
    Ptr<T, Demention, Demention-1> operator [] (size_t n) {
        return Ptr<T, Demention, Demention-1>(*this, n);
    }
    
    const Ptr<T, Demention, Demention-1> operator [] (size_t n) const {
        return Ptr<T, Demention, Demention-1>(*this, n);
    }
    
    
    friend std::istream& operator >> (std::istream &   si,
                                      GuardTypeArray& gt) {
        T data;
        if(GuardConfig::_ARRAY_IO_TIP_SWITCH == true) {
            if(typeid(si) == typeid(std::cin)) {
                std::cout<< "Please input ";
                std::cout<< "["<< gt.size() << "] Datas "
                << gt.id << ": " << std::endl;
            }
        }
        T * arr = gt.array;
        for (int i=0; i<gt.size(); i++) {
            si >> data;
            arr[i] = data;
        }
        return si;
    }
    
    friend std::ostream& operator << (std::ostream &        so,
                                      const GuardTypeArray& gt) {
        {
            T* p = gt.array;
            for (int i=0; i<gt.size(); i++) {
                so << std::setw(GuardConfig::_ARRAY_OUT_PUT_INTERVAL)
                << " " << *(p+i) << " ";
            }
            so << std::endl << std::endl;
            return so;
        }
    }
};

#endif /* GuardTypeArrayN_hpp */
