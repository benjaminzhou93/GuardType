//
//  Ptr.hpp
//  GuardType
//
//  Created by BenjaminZhou on 16/4/13.
//  Copyright © 2016年 BenjaminZhou. All rights reserved.
//

#ifndef Ptr_hpp
#define Ptr_hpp

#include "GuardType.hpp"

template<typename T, int Demention>
class ArrayIndexProvider;

template<typename T, int Demention>
class GuardTypeArray;

//--------------------------------------------------------------------------
//                            class Ptr

template<typename T, int Demention>
class Ptr<T, Demention, 1> {
public:
    typedef std::random_access_iterator_tag     iterator_category;
    typedef GuardType<T>                        value_type;
    typedef size_t                              difference_type;
    typedef Ptr                                 pointer;
    typedef GuardType<T>                        reference;
private:
    Ptr();
protected:
    ArrayIndexProvider<T, Demention> data;
public:
    
    Ptr(const ArrayIndexProvider<T, Demention>& index, size_t n)
    : data(index, 1-1, n){
    }
    
    Ptr(const GuardTypeArray<T, 2>& arr, size_t n)
    : data(arr, n) {
    }
    
    Ptr(const Ptr& ptr)
    : data(ptr.data, 0, 0) {
    }
    
    GuardType<T> operator [] (size_t m) {
        DataProvider<T> * data = new ArrayIndexProvider<T, Demention>(this->data, 0, m);
        return GuardType<T>(data);
    }
    
    const GuardType<T> operator [] (size_t m) const {
        DataProvider<T> * data = new ArrayIndexProvider<T, Demention>(this->data, 0, m);
        return GuardType<T>(data);
    }
    
    const Ptr<T, Demention, 1>& operator = (const Ptr<T, Demention, 1>& ptr) {
        this->data.pos = ptr.data.pos;
        this->data.array = ptr.data.array;
        return *this;
    }
    
    GuardType<T> operator * () {
        DataProvider<T> * data = new ArrayIndexProvider<T, Demention>(this->data, 0, 0);
        return GuardType<T>(data);
    }
    
    const GuardType<T> operator * () const {
        DataProvider<T> * data = new ArrayIndexProvider<T, Demention>(this->data, 0, 0);
        return GuardType<T>(data);
    }
    
    operator const T* () const {
        return this->data.pos;
    }
    
    bool operator < (const Ptr<T, Demention, 1>& ptr) const {
        return this->data.pos < ptr.data.pos;
    }
    
    bool operator <= (const Ptr<T, Demention, 1>& ptr) const {
        return this->data.pos <= ptr.data.pos;
    }
    
    bool operator > (const Ptr<T, Demention, 1>& ptr) const {
        return this->data.pos > ptr.data.pos;
    }
    
    bool operator >= (const Ptr<T, Demention, 1>& ptr) const {
        return this->data.pos >= ptr.data.pos;
    }
    
    bool operator == (const Ptr<T, Demention, 1>& ptr) const {
        return this->data.pos == ptr.data.pos;
    }
    
    bool operator != (const Ptr<T, Demention, 1>& ptr) const {
        return this->data.pos != ptr.data.pos;
    }
    
    bool operator == (const T* ptr) const {
        return this->data.pos == ptr;
    }
    
    bool operator != (const T* ptr) const {
        return this->data.pos != ptr;
    }
    
    Ptr<T, Demention, 1> operator + (size_t i) const {
        return Ptr<T, Demention, 1>(this->data, i);
    }
    
    Ptr<T, Demention, 1> operator - (size_t i) const {
        return Ptr<T, Demention, 1>(this->data, -1*i);
    }
    
    Ptr<T, Demention, 1>&operator += (size_t i) {
        Ptr<T, Demention, 1>(this->data, i);
        this->data.pos += i;
        return *this;
    }
    
    Ptr<T, Demention, 1>&operator -= (size_t i) {
        Ptr<T, Demention, 1>(this->data, -1*i);
        this->data.pos -= i;
        return *this;
    }
    
    Ptr<T, Demention, 1>&operator ++ () {
        Ptr<T, Demention, 1>(this->data, 1);
        this->data.pos += 1;
        return *this;
    }
    
    Ptr<T, Demention, 1> operator ++ (int) {
        Ptr<T, Demention, 1> ret(this->data, 1);
        this->data.pos += 1;
        return ret;
    }
    
    Ptr<T, Demention, 1>& operator -- () {
        Ptr<T, Demention, 1>(this->data, -1);
        this->data.pos -= 1;
        return *this;
    }
    
    Ptr<T, Demention, 1> operator -- (int) {
        Ptr<T, Demention, 1> ret(this->data, -1);
        this->data.pos -= 1;
        return ret;
    }
    
    size_t operator - (const Ptr<T, Demention, 1>& ptr) const {
        return this->data.pos-ptr.data.pos;
    }
};

#endif /* Ptr_hpp */
