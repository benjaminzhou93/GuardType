//
//  PtrN.hpp
//  GuardType
//
//  Created by BenjaminZhou on 16/4/13.
//  Copyright © 2016年 BenjaminZhou. All rights reserved.
//

#ifndef PtrN_hpp
#define PtrN_hpp

#include "GuardType.hpp"
#include "Ptr.hpp"

template<typename T, int Demention>
class ArrayIndexProvider;

template<typename T, int Demention>
class GuardTypeArray;

//--------------------------------------------------------------------------
//                            class Ptr

template<typename T, int Demention, int PtrN>
class Ptr {
private:
    Ptr();
protected:
    ArrayIndexProvider<T, Demention> data;
    
public:
    Ptr(const ArrayIndexProvider<T, Demention>& index, size_t n)
    : data(index, PtrN, n){
    }
    
    Ptr(const GuardTypeArray<T, Demention>& arr, size_t n)
    : data(arr, n){
    }
    
    Ptr<T, Demention, PtrN-1> operator [] (size_t m) {
        return Ptr<T, Demention, PtrN-1>(this->data, m);
    }
    
    const Ptr<T, Demention, PtrN-1> operator [] (size_t m) const {
        return Ptr<T, Demention, PtrN-1>(this->data, m);
    }
    
    Ptr<T, Demention, PtrN-1> operator * () {
        return Ptr<T, Demention, PtrN-1>(this->data, 0);
    }
    
    const Ptr<T, Demention, PtrN-1> operator * () const {
        return Ptr<T, Demention, PtrN-1>(this->data, 0);
    }
    
    const Ptr<T, Demention, PtrN>& operator = (const Ptr<T, Demention, PtrN>& ptr) {
        this->data.pos = ptr.data.pos;
        this->data.array = ptr.data.array;
        return *this;
    }
};

#endif /* PtrN_hpp */
