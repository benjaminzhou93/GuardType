//
//  NumericProvider.hpp
//  GuardType
//
//  Created by BenjaminZhou on 16/4/13.
//  Copyright © 2016年 BenjaminZhou. All rights reserved.
//

#ifndef NumericProvider_hpp
#define NumericProvider_hpp


#include "DataProvider.hpp"

//--------------------------------------------------------------------------
//                            class NumericProvider

template<typename T>
class NumericProvider : public DataProvider<T> {
    T data;
    std::string id;
public:
    
    NumericProvider(const std::string& id = "") : data() {
        this->id = (id == "" ? GT::GetNewId() : id);
    }
    
    NumericProvider(const T& data) : data(data) {
        this->id = GT::GetNewId();
    }
    
    virtual T& Data()  {
        return data;
    }
    
    virtual const std::string Id() const {
        return id;
    }
};

#endif /* NumericProvider_hpp */
